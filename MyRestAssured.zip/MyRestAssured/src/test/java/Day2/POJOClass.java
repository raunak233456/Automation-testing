package Day2;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.json.JSONObject;
import org.testng.annotations.Test;

public class POJOClass {//generate getters and setters, go to sources select generate getter and setter
	
	//plain old java object
	//An ordinary Java class that does not extends or implement properties from any technology or 
	//framework-related classes and interface is called a POJO class. POJO classes are used to represent data.
	

	
	String name;
	String location;
	String phone;
	String courses[];
	
	
	
		public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String[] getCourses() {
		return courses;
	}
	public void setCourses(String[] courses) {
		this.courses = courses;
	}
		


}


