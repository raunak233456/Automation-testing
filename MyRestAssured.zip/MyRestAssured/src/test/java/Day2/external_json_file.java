package Day2;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.testng.annotations.Test;

public class external_json_file {
	@Test
	void testPOJO() throws FileNotFoundException
	{
	
		File f = new File(".\\body.json");//file and file reader
		
		FileReader fr = new FileReader(f);
		
	//open file
		JSONTokener jt = new JSONTokener(fr);//json tokener
		JSONObject p = new JSONObject(jt);                  //extract data
		
	given()
	//type of data sending
	.contentType("application/json")
	.body(p.toString())//can not send data directly, need to convert to string

	.when()
	      .post("http://localhost:3000/students")
	      

	.then()
	.statusCode(201)
	.body("name",equalTo("John"))
	.body("location",equalTo("india"))
	.body("courses[0]",equalTo("Java"))
	.log().all();

	}
}
