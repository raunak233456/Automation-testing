package Day3;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.response.Response;



public class testCookies {

	@Test
	/*void cookies()
	{
		given()
		
		.when()
		.get("https://www.google.com/")
		
		.then()
		.cookie("AEC","Ad49MVH6LN92Gy9WBW34_7oNAm-qCxw2vceeCEfV-RYZH85dWvpzjEhb6g")
		.statusCode(200)
		.log().all();
		

	}*/
	
	void getcookiesInfo()
	{
		Response res = given()
				.when()
				.get("https://www.google.com/");
				
			
				
				String cookie = res.getCookie("AEC");//to get single cookies
			System.out.println(cookie);
			
			//to get all cookies value
			
			Map<String , String> mp = res.getCookies();
			for(String k :mp.keySet())
			{
				String val = res.getCookie(k);
				System.out.println(k+" " +val);
			}
				
	}
}
